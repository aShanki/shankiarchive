OptiFine is required for most pack features to work

Connected Textures must be set to Fast or Fancy in Video Settings -> Quality

Contact ApplePies#7974 on Discord for further support